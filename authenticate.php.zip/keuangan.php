<?php
include 'config.php';

// Pastikan hanya user role keuangan yang bisa akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'keuangan') {
    header("Location: login.php");
    exit;
}

// =============================
// Query daftar folder
// =============================
$folders = $conn->query("SELECT * FROM folders ORDER BY created_at DESC");

// =============================
// Query daftar file
// =============================
$sql = "SELECT f.id, f.filename, f.filepath, f.uploaded_by, f.uploaded_at, d.name AS folder_name
        FROM files f
        JOIN folders d ON f.folder_id = d.id
        ORDER BY f.uploaded_at DESC";
$files = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Keuangan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:#f8f9fa;">
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold text-primary">📊 Dashboard Keuangan</h2>
      <div>
        <a href="dashboard.php" class="btn btn-secondary">⬅ Kembali</a>
        <a href="logout.php" class="btn btn-danger">🚪 Sign Out</a>
      </div>
    </div>

    <!-- ================== Daftar Folder ================== -->
    <h3>📂 Daftar Folder</h3>
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Nama Folder</th>
          <th>Tahun</th>
          <th>Kegiatan</th>
          <th>Bidang</th>
          <th>Tanggal Dibuat</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($folders && $folders->num_rows > 0): ?>
          <?php while($f = $folders->fetch_assoc()): ?>
          <tr>
            <td><?= $f['id'] ?></td>
            <td><?= htmlspecialchars($f['name']) ?></td>
            <td><?= $f['tahun'] ?></td>
            <td><?= htmlspecialchars($f['kegiatan']) ?></td>
            <td><?= htmlspecialchars($f['bidang']) ?></td>
            <td><?= $f['created_at'] ?></td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6" class="text-center">Belum ada folder</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <!-- ================== Daftar File ================== -->
    <h3 class="mt-5">📄 Daftar File</h3>
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Nama File</th>
          <th>Folder</th>
          <th>Upload Oleh</th>
          <th>Tanggal Upload</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($files && $files->num_rows > 0): ?>
          <?php while($file = $files->fetch_assoc()): ?>
          <tr>
            <td><?= $file['id'] ?></td>
            <td><?= htmlspecialchars($file['filename']) ?></td>
            <td><?= htmlspecialchars($file['folder_name']) ?></td>
            <td><?= htmlspecialchars($file['uploaded_by']) ?></td>
            <td><?= $file['uploaded_at'] ?></td>
            <td>
              <a href="<?= $file['filepath'] ?>" target="_blank" class="btn btn-sm btn-primary">Lihat</a>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6" class="text-center">Belum ada file</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
