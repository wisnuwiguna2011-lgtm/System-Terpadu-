// Jika sudah login langsung ke dashboard sesuai role
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php"); // Arahkan ke dashboard.php saja
    exit;
}