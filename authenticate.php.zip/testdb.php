<?php
include 'config.php';
echo "✅ Koneksi berhasil ke database: " . $db;
?>
