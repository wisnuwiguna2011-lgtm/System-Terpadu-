<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'config.php';

// 🚫 proteksi hanya admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$message = "";

/* =====================
   Tambah User
===================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = trim($_POST['role']);

    if (!in_array($role, ['admin', 'user'])) {
        $message = "<div class='alert alert-danger'>Role tidak valid!</div>";
    } elseif ($username && $password) {
        // ✅ cek duplikat
        $cek = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $cek->bind_param("s", $username);
        $cek->execute();
        $cek->store_result();

        if ($cek->num_rows > 0) {
            $message = "<div class='alert alert-warning'>Username sudah ada, gunakan yang lain!</div>";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $username, $hashedPassword, $role);

            if ($stmt->execute()) {
                $message = "<div class='alert alert-success'>User berhasil ditambahkan!</div>";
            } else {
                $message = "<div class='alert alert-danger'>Gagal menambahkan user: " . $stmt->error . "</div>";
            }
        }
        $cek->close();
    } else {
        $message = "<div class='alert alert-warning'>Semua field wajib diisi!</div>";
    }
}

/* =====================
   Edit User
===================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    $id       = intval($_POST['id']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = trim($_POST['role']);

    if (!in_array($role, ['admin', 'user'])) {
        $message = "<div class='alert alert-danger'>Role tidak valid!</div>";
    } elseif ($username) {
        // ✅ cek duplikat username selain dirinya sendiri
        $cek = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $cek->bind_param("si", $username, $id);
        $cek->execute();
        $cek->store_result();

        if ($cek->num_rows > 0) {
            $message = "<div class='alert alert-warning'>Username sudah dipakai user lain!</div>";
        } else {
            if ($password) {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $sql = "UPDATE users SET username=?, password=?, role=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssi", $username, $hashedPassword, $role, $id);
            } else {
                $sql = "UPDATE users SET username=?, role=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssi", $username, $role, $id);
            }

            if ($stmt->execute()) {
                $message = "<div class='alert alert-success'>User berhasil diperbarui!</div>";
            } else {
                $message = "<div class='alert alert-danger'>Gagal mengedit user: " . $stmt->error . "</div>";
            }
        }
        $cek->close();
    } else {
        $message = "<div class='alert alert-warning'>Username wajib diisi!</div>";
    }
}

/* =====================
   Hapus User
===================== */
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-success'>User berhasil dihapus!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Gagal menghapus user: " . $stmt->error . "</div>";
    }
}

/* =====================
   Filter & Pencarian
===================== */
$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$filter_role = isset($_GET['role']) ? $_GET['role'] : "";

$sql = "SELECT id, username, role FROM users WHERE 1=1";
$params = [];
$types  = "";

// pencarian
if ($search !== "") {
    $sql .= " AND username LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}
// filter role
if ($filter_role !== "" && in_array($filter_role, ["user", "admin"])) {
    $sql .= " AND role = ?";
    $params[] = $filter_role;
    $types .= "s";
}

$sql .= " ORDER BY id ASC";
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Pengguna</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin Panel</a>
    <div class="d-flex">
      <a href="keuangan.php" class="btn btn-outline-light me-2">⬅️ Kembali ke Menu</a>
      <a href="logout.php" class="btn btn-danger">🚪 Sign Out</a>
    </div>
  </div>
</nav>

  <div class="container mt-5">
    <h3>👥 Kelola Pengguna</h3>
    <?= $message ?>

    <!-- Form tambah user -->
    <div class="card p-4 shadow-sm mb-4">
      <h5 class="mb-3">Tambah User Baru</h5>
      <form method="POST">
        <input type="hidden" name="tambah" value="1">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Role</label>
          <select name="role" class="form-select" required>
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Tambah User</button>
        <a href="dashboard_admin.php" class="btn btn-secondary">Kembali</a>
      </form>
    </div>

    <!-- Filter & Pencarian -->
    <div class="card p-4 shadow-sm mb-4">
      <h5 class="mb-3">🔍 Cari & Filter User</h5>
      <form method="GET" class="row g-3">
        <div class="col-md-5">
          <input type="text" name="search" class="form-control" placeholder="Cari username..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-md-4">
          <select name="role" class="form-select">
            <option value="">-- Semua Role --</option>
            <option value="user" <?= $filter_role=="user"?"selected":"" ?>>User</option>
            <option value="admin" <?= $filter_role=="admin"?"selected":"" ?>>Admin</option>
          </select>
        </div>
        <div class="col-md-3">
          <button type="submit" class="btn btn-primary w-100">Filter</button>
        </div>
      </form>
    </div>

    <!-- Daftar user -->
    <div class="card p-4 shadow-sm">
      <h5 class="mb-3">Daftar User</h5>
      <table class="table table-bordered table-striped align-middle">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Role</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['role']) ?></td>
            <td>
              <!-- Tombol Edit (modal) -->
              <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id'] ?>">Edit</button>
              <a href="kelola_pengguna.php?hapus=<?= $row['id'] ?>" 
                 class="btn btn-danger btn-sm"
                 onclick="return confirm('Yakin ingin menghapus user ini?')">Hapus</a>
            </td>
          </tr>

          <!-- Modal Edit -->
          <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <form method="POST">
                  <input type="hidden" name="edit" value="1">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <div class="mb-3">
                      <label class="form-label">Username</label>
                      <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($row['username']) ?>" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Password (kosongkan jika tidak diubah)</label>
                      <input type="password" name="password" class="form-control">
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Role</label>
                      <select name="role" class="form-select" required>
                        <option value="user" <?= $row['role']=='user'?'selected':'' ?>>User</option>
                        <option value="admin" <?= $row['role']=='admin'?'selected':'' ?>>Admin</option>
                      </select>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
