<?php
include "config.php";

// username dan password baru
$admin_user = "admin";
$new_pass   = "admin123"; // ganti jika mau password lain
$admin_role = "admin";

// generate hash password
$hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);

// cek apakah user admin sudah ada
$sql_check = "SELECT * FROM users WHERE username='$admin_user'";
$result = $conn->query($sql_check);

if ($result->num_rows > 0) {
    // update password & role
    $sql_update = "UPDATE users SET password='$hashed_pass', role='$admin_role' WHERE username='$admin_user'";
    if ($conn->query($sql_update) === TRUE) {
        echo "✅ User admin berhasil direset.<br>";
        echo "Username: <b>$admin_user</b><br>";
        echo "Password: <b>$new_pass</b><br>";
    } else {
        echo "Error update: " . $conn->error;
    }
} else {
    // jika belum ada, buat baru
    $sql_insert = "INSERT INTO users (username, password, role) VALUES ('$admin_user', '$hashed_pass', '$admin_role')";
    if ($conn->query($sql_insert) === TRUE) {
        echo "✅ User admin berhasil dibuat.<br>";
        echo "Username: <b>$admin_user</b><br>";
        echo "Password: <b>$new_pass</b><br>";
    } else {
        echo "Error insert: " . $conn->error;
    }
}

$conn->close();
?>
