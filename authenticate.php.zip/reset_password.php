<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $newpass  = trim($_POST['password']);

    if ($username && $newpass) {
        $hash = password_hash($newpass, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $hash, $username);
        $ok = $stmt->execute();

        if ($ok) {
            echo "✅ Password untuk user <b>{$username}</b> berhasil direset.<br>";
            echo "Silakan login lagi dengan password baru.";
        } else {
            echo "❌ Gagal reset: " . $stmt->error;
        }
    } else {
        echo "❌ Username dan password tidak boleh kosong.";
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Reset Password User</title>
  <style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; padding:30px; }
    form { background:white; padding:20px; border-radius:10px; max-width:400px; margin:auto; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
    input { display:block; width:100%; margin-bottom:15px; padding:10px; border:1px solid #ccc; border-radius:5px; }
    button { background:#007bff; color:white; padding:10px; border:none; border-radius:5px; cursor:pointer; }
    button:hover { background:#0056b3; }
  </style>
</head>
<body>
  <h2>Reset Password User</h2>
  <form method="post">
    <label>Username:</label>
    <input type="text" name="username" required>

    <label>Password Baru:</label>
    <input type="text" name="password" required>

    <button type="submit">Reset Password</button>
  </form>
</body>
</html>
