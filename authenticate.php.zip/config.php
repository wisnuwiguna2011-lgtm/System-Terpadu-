<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Konfigurasi database (isi sesuai data MySQL di cPanel)
$host = "localhost";
$user = "urhg326v_userarsip";     // Ganti dengan username database di cPanel
$pass = "StrongPass#2025";        // Ganti dengan password database
$db   = "urhg326v_dbarsip";       // Ganti dengan nama database

// Membuat koneksi ke database
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// TAMBAHKAN BARIS INI UNTUK SET KARAKTER UTF-8
$conn->set_charset("utf8mb4");

// Optional: Tampilkan pesan sukses jika dalam mode development
// echo "Koneksi database berhasil dan charset UTF-8 diatur!";
?>