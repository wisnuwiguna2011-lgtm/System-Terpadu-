<?php 
session_start(); 
if(!isset($_SESSION['username'])){ 
  header("Location:index.php"); 
  exit; 
} 
?>

<?php
session_start();

// 🚫 Kalau belum login, redirect ke login.php
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}

// ✅ Simpan info login
$username = $_SESSION['username'];
$role     = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap & FontAwesome -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark px-4">
  <a class="navbar-brand fw-bold" href="dashboard.php">
    <i class="fa-solid fa-gauge-high me-2"></i>Dashboard
  </a>
  <div class="d-flex align-items-center">
    <span class="text-white me-3">
      Halo, <?= htmlspecialchars($_SESSION['username']) ?> (<?= $_SESSION['role'] ?>)
    </span>
    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
  </div>
</nav>

<div class="container py-5">
  <h3 class="mb-4 text-center fw-bold">Menu Admin</h3>
  <div class="row g-4 justify-content-center">
    <?php if($_SESSION['role']=='admin'): ?>
    <div class="col-md-3 col-6">
      <a href="users.php" class="btn btn-lg btn-primary w-100 shadow-sm rounded-4 py-4">
        <i class="fa fa-users fa-2x mb-2"></i><br>Kelola Pengguna
      </a>
    </div>
    <div class="col-md-3 col-6">
      <a href="laporan.php" class="btn btn-lg btn-success w-100 shadow-sm rounded-4 py-4">
        <i class="fa fa-file-alt fa-2x mb-2"></i><br>Laporan
      </a>
    </div>
    <div class="col-md-3 col-6">
      <a href="settings.php" class="btn btn-lg btn-warning w-100 shadow-sm rounded-4 py-4">
        <i class="fa fa-cogs fa-2x mb-2"></i><br>Pengaturan
      </a>
    </div>
    <?php endif; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.
