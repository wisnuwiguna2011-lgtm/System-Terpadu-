<?php
// test_db.php
// --- Konfigurasi database ---
$host = "localhost";                  // host database
$user = "urhg326v_Admin";             // username MySQL
$pass = "TZATWjlU2XrH";               // password MySQL
$db   = "urhg326v_db_kearsipan";      // nama database

// --- Coba koneksi ---
$conn = new mysqli($host, $user, $pass, $db);

// --- Cek hasil koneksi ---
if ($conn->connect_errno) {
    echo "<h2 style='color:red;'>Koneksi GAGAL!</h2>";
    echo "Error: " . $conn->connect_error;
} else {
    echo "<h2 style='color:green;'>Koneksi BERHASIL!</h2>";
    echo "Tersambung ke database: <b>" . $db . "</b>";
}

// Tutup koneksi
$conn->close();
?>
