<?php
session_start();
include 'config.php';

// 🚫 proteksi login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];
$message = "";

// 📂 proses upload file
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['document'])) {
    $targetDir = "uploads/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = basename($_FILES['document']['name']);
    $targetFile = $targetDir . time() . "_" . $fileName;

    if (move_uploaded_file($_FILES['document']['tmp_name'], $targetFile)) {
        // simpan ke database
        $sql = "INSERT INTO documents (filename, filepath, uploaded_by) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $fileName, $targetFile, $username);
        $stmt->execute();

        $message = "<div class='alert alert-success'>✅ File berhasil diupload!</div>";
    } else {
        $message = "<div class='alert alert-danger'>❌ Gagal upload file!</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Upload Dokumen</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-4">
    <h3>📤 Upload Dokumen</h3>
    <a href="keuangan.php" class="btn btn-secondary btn-sm mb-3">⬅ Kembali</a>

    <?= $message ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Pilih File</label>
        <input type="file" name="document" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Upload</button>
    </form>

    <hr>
    <h5>📑 Daftar Dokumen</h5>
    <table class="table table-bordered">
      <tr>
        <th>No</th>
        <th>Nama File</th>
        <th>Uploader</th>
        <th>Tanggal Upload</th>
        <th>Aksi</th>
      </tr>
      <?php
      $result = $conn->query("SELECT * FROM documents ORDER BY created_at DESC");
      $no = 1;
      while ($row = $result->fetch_assoc()) {
          echo "<tr>
            <td>{$no}</td>
            <td>{$row['filename']}</td>
            <td>{$row['uploaded_by']}</td>
            <td>{$row['created_at']}</td>
            <td><a href='{$row['filepath']}' target='_blank' class='btn btn-sm btn-success'>Lihat</a></td>
          </tr>";
          $no++;
      }
      ?>
    </table>
  </div>
</body>
</html>
